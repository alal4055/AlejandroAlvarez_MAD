package com.example.alejandroalvarez.cupappnew;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    public ImageView cupLeft, cupMiddle, cupRight, ball1, ball2, ball3;
    TextView scoreText;
    int startP = 0;
    int score = 0;
    boolean cupContinue = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cupLeft = (ImageView) findViewById(R.id.cupLeft);
        cupMiddle = (ImageView) findViewById(R.id.cupMiddle);
        cupRight = (ImageView) findViewById(R.id.cupRight);
        ball1 = (ImageView) findViewById(R.id.ball1);
        ball2 = (ImageView) findViewById(R.id.ball2);
        ball3 = (ImageView) findViewById(R.id.ball3);
        scoreText = (TextView) findViewById(R.id.scoreView);
    }

    public int getRandomNumber(View view) {
        Random rand = new Random();
        int newNumber = rand.nextInt(3); // Gives n such that 0 <= n < 20
        return newNumber;
    }

    public void setBall(View view) {
        if (cupContinue == true) {
        ball1.setImageResource(R.drawable.nothing);
        ball2.setImageResource(R.drawable.nothing);
        ball3.setImageResource(R.drawable.nothing);
            Toast toast = Toast.makeText(getApplicationContext(), "Placing Ball Randomly", Toast.LENGTH_SHORT);
            toast.show();
            int rndNumber = getRandomNumber(view);
            if (rndNumber == 0) {
                ball1.setImageResource(R.drawable.ball);
                startP = 0;
            } else if (rndNumber == 1) {
                ball2.setImageResource(R.drawable.ball);
                startP = 1;
            } else {
                ball3.setImageResource(R.drawable.ball);
                startP = 2;
            }
            cupContinue = false;
        } else {
            Toast toast = Toast.makeText(getApplicationContext(), "Must Pick Cup", Toast.LENGTH_SHORT);
            toast.show();
        }
    }


    public void animateToUp(View view, ImageView cup, int yPosition) {
        Animation animation = new TranslateAnimation(Animation.ABSOLUTE, Animation.ABSOLUTE, Animation.ABSOLUTE, yPosition);
        animation.setDuration(3000);
        animation.setFillEnabled(true);
        cup.startAnimation(animation);
    }

    public void checkMiddle(View view) {
        if (cupContinue == false) {
            animateToUp(view, cupMiddle, -200);
            if (startP == 1) {
                Toast toast = Toast.makeText(getApplicationContext(), "Correct!", Toast.LENGTH_SHORT);
                toast.show();
                score++;
            } else {
                Toast toast = Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_SHORT);
                toast.show();
                score--;
            }
            scoreText.setText(String.valueOf(score));
            cupContinue = true;
        } else {
            Toast toast = Toast.makeText(getApplicationContext(), "You Must Press The Mix Button", Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    public void checkRight(View view) {
        if (cupContinue == false) {
            animateToUp(view, cupRight, -200);
            if (startP == 2) {
                Toast toast = Toast.makeText(getApplicationContext(), "Correct!", Toast.LENGTH_SHORT);
                toast.show();
                score++;
            } else {
                Toast toast = Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_SHORT);
                toast.show();
                score--;
            }
            scoreText.setText(String.valueOf(score));
            cupContinue = true;
        } else {
            Toast toast = Toast.makeText(getApplicationContext(), "You Must Press The Mix Button", Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    public void checkLeft(View view) {
        if (cupContinue == false) {
            animateToUp(view, cupLeft, -200);
            if (startP == 0) {
                Toast toast = Toast.makeText(getApplicationContext(), "Correct!", Toast.LENGTH_SHORT);
                toast.show();
                score++;
            } else {
                Toast toast = Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_SHORT);
                toast.show();
                score--;
            }
            scoreText.setText(String.valueOf(score));
            cupContinue = true;
        } else {
            Toast toast = Toast.makeText(getApplicationContext(), "You Must Press The Mix Button", Toast.LENGTH_SHORT);
            toast.show();
        }
    }
}
