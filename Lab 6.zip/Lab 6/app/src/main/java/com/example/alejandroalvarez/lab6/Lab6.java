package com.example.alejandroalvarez.lab6;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;


public class Lab6 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab6);

        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Labs(v);
            }
        });

    }



    public void Labs (View view){
        String spinnerString;

        Spinner spin = (Spinner)findViewById(R.id.spinner);
        Integer spinnerNumber  = spin.getSelectedItemPosition();
if(spinnerNumber == 0){
    spinnerString ="You should run to the gym instead of driving to reduce emissions.";
}
else if(spinnerNumber == 1){
            spinnerString ="You should carpool to work to reduce emissions.";
        }

else if(spinnerNumber == 2){
    spinnerString ="You should eat vegetables to reduce emissions.";
}

else if(spinnerNumber == 3){
    spinnerString ="You should complete all your errands in one trip to reduce emissions.";
}

else {
    spinnerString ="You should avoid electronics to reduce emissions.";
}


        Intent intent = new Intent(this, hobby.class);
        intent.putExtra("spinnerStringOne", spinnerString);
        startActivity(intent);
    }
}