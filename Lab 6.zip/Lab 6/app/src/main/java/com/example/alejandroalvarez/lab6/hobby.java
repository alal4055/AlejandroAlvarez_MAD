package com.example.alejandroalvarez.lab6;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

/**
 * Created by alejandroalvarez on 12/5/17.
 */

public class hobby extends AppCompatActivity{

private String message;
private String adviceURL= "https://www.tva.gov/Energy/EnergyRightSolutions/EnergyRight-Solutions-for-Home/Energy-Efficiency-Advice";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acitvity_hobby);

        Intent intent = getIntent();
       message= intent.getStringExtra("spinnerStringOne");

        TextView spinnerMessage = (TextView) findViewById(R.id.textView2);
        spinnerMessage.setText(message);
    }

    public void toAdvice(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(adviceURL));
        startActivity(intent);
    }

}
