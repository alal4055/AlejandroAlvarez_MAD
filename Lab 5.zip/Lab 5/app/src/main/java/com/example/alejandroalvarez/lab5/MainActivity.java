package com.example.alejandroalvarez.lab5;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //text view
        TextView  textFinal = (EditText) findViewById(R.id.editText2);

        TextView  textEnd = (TextView) findViewById(R.id.textView3);
    }


   public void setupApp(View view){
    double finalValue = 0;

       Spinner percentages = (Spinner)findViewById(R.id.spinner);
       String percentagesPick = String.valueOf(percentages.getSelectedItem());

       //check boxes
       CheckBox rounding = (CheckBox)findViewById(R.id.checkBox3);
       boolean roundBool = rounding.isChecked();

       //text view
       TextView  textFinal = (EditText) findViewById(R.id.editText2);
       String textString = textFinal.getText().toString();

       TextView  textEnd = (TextView) findViewById(R.id.textView3);

        double percentagesPickDouble = Double.parseDouble(percentagesPick) ;
       double textStringDouble = Double.parseDouble(textString);

       //radio buttons
       RadioGroup cost = (RadioGroup)findViewById(R.id.radios);
       int textColor = cost.getCheckedRadioButtonId();

       finalValue = ((percentagesPickDouble/100)*textStringDouble);

        String finalValueString ="$" + Double.toString(finalValue);
       double finalValueRound = Math.round(finalValue);
       String finalValueRoundString ="$" + Double.toString(finalValueRound);


       Context context = getApplicationContext();
       String words = "Loading...";
       int timer = Toast.LENGTH_SHORT;
       Toast.makeText(context, words, timer).show();


       if (roundBool) {
           textEnd.setText(finalValueRoundString);
       } else{
           textEnd.setText(finalValueString);
       }


    }


    public void changeColor(View view) {
        //radio buttons
        RadioGroup cost = (RadioGroup)findViewById(R.id.radios);
        int textColor = cost.getCheckedRadioButtonId();

        //text view
        TextView  textFinal1 = (TextView) findViewById(R.id.textView3);

        if(textColor == R.id.radioButton1){
            textFinal1.setTextColor(Color.rgb(0,0,255));
        }
        else if (textColor ==R.id.radioButton3){
            textFinal1.setTextColor(Color.rgb(255,0,0));
        }
        else{
            textFinal1.setTextColor(Color.rgb(0,0,0));
        }
    }
}
