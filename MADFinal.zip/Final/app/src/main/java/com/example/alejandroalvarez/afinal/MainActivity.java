package com.example.alejandroalvarez.afinal;

import android.content.Intent;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    private String placeURL="http://illegalpetes.com/";
    private String place="The Hill";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView imageView = (ImageView)findViewById(R.id.imageView);
        imageView.setImageResource(android.R.color.transparent);
    }

    public void buildBurrito(View view) {

        EditText burritoName = (EditText) findViewById(R.id.nameBurrito);
        String bN = burritoName.getText().toString();
        //get spinner
        Spinner locationsSpinner = (Spinner)findViewById(R.id.spinner);
        //get spinner item array position
        Integer locations = locationsSpinner.getSelectedItemPosition();

        Switch glutenSwitch = (Switch)findViewById(R.id.gluten);
        Boolean glutenBool = glutenSwitch.isChecked();
        CheckBox salsa= (CheckBox)findViewById(R.id.salsa);
        CheckBox sourCream= (CheckBox)findViewById(R.id.sourCream);
        CheckBox guacamole= (CheckBox)findViewById(R.id.guacamole);
        CheckBox cheese= (CheckBox)findViewById(R.id.cheese);
        Boolean salsaBool = salsa.isChecked();
        Boolean sourCreamBool = sourCream.isChecked();
        Boolean guacamoleBool = guacamole.isChecked();
        Boolean cheeseBool = cheese.isChecked();
        RadioButton burrito = (RadioButton)findViewById(R.id.burrito);
        RadioButton taco = (RadioButton)findViewById(R.id.taco);
        Boolean burritoBool = burrito.isChecked();
        Boolean tacoBool = taco.isChecked();
        ToggleButton filling= (ToggleButton)findViewById(R.id.filling);
        Boolean fillingBool= filling.isChecked();
        TextView description = (TextView)findViewById(R.id.description);
        ImageView imageView = (ImageView)findViewById(R.id.imageView);


        String fillingString="";
        String glutenString="";
        String salsaString="";
        String sourCreamString="";
        String guacamoleString="";
        String cheeseString="";
        String mealString="";

        if(locations==0){
            place = "The Hill";
            placeURL="http://illegalpetes.com/";
        }
        else if(locations==1){
            place = "29th Street";
            placeURL="https://www.chipotle.com/";
        }
        else if(locations==null){
            place = "The Hill";
            placeURL="https://www.chipotle.com/";
        }
        else{
            place = "Pearl Street";
            placeURL="https://bartaco.com/";
        }

        if(tacoBool){
            mealString=" taco";
            imageView.setImageResource(R.drawable.taco);
        }
        else if(burritoBool){
            mealString=" burrito";
            imageView.setImageResource(R.drawable.burrito);
        }
        else{
            mealString=" not selected";
            imageView.setImageResource(android.R.color.transparent);
        }

        if(!fillingBool){
            fillingString="meat, ";
        }
        else{
            fillingString="veggies, ";
        }
        if(!glutenBool){
            glutenString="flour tortilla ";
        }
        else{
            glutenString="corn tortilla ";
        }
        if(!salsaBool){
            salsaString="";
        }
        else{
            salsaString="salsa, ";
        }
        if(!sourCreamBool){
            sourCreamString="";
        }
        else{
            sourCreamString="sour cream,";
        }
        if(!guacamoleBool){
            guacamoleString="";
        }
        else{
            guacamoleString="guacamole, ";
        }
        if(!guacamoleBool){
            cheeseString="";
        }
        else{
            cheeseString="cheese ";
        }

        String descriptionAll = "The " + bN + mealString  +" with " + fillingString + salsaString + sourCreamString + guacamoleString +cheeseString+". You should also get a " + glutenString +".  Go to " + place+"." ;
                description.setText(descriptionAll);

    }

    public void findBurrito(View view) {
        //create an Intent
        Intent intent = new Intent(this, secondActivity.class);

        //pass data
        intent.putExtra("burritoShopName", place);
        intent.putExtra("burritoShopURL", placeURL);

        //start intent
        startActivity(intent);

    }
}
