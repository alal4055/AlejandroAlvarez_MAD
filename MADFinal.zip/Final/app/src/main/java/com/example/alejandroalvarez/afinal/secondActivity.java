package com.example.alejandroalvarez.afinal;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

/**
 * Created by alejandroalvarez on 12/17/17.
 */

public class secondActivity extends AppCompatActivity {
    private String burritoShop;
    private String burritoShopURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_activity);

        //get intent
        Intent intent = getIntent();
        burritoShop = intent.getStringExtra("burritoShopName");
        burritoShopURL = intent.getStringExtra("burritoShopURL");
        Log.i("shop received", burritoShop);
        Log.i("url received", burritoShopURL);

        TextView eatHere = (TextView)findViewById(R.id.eatAt);
        eatHere.setText("You should eat at " + burritoShop);
    }

    public void loadWebSite(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(burritoShopURL));
        startActivity(intent);
    }

}
